<?php
include '../db_conn.php';
if (isset($_SESSION['Username'])) {
if ($_SESSION['Username']==="Admin@fresh.com") {

}
else {
 die("Error: You are not logged in as admin and do not have premission to view this page.");
}
}
else {
die("Error: You are not logged in as admin and do not have premission to view this page.");
}


?>










<html>
<head>
<title>Searh or Delete Customers</title>
<div id="menu" class="fas fa-bars"></div>
<a href="../index.php" class="logo"><img src="Fresh-As-Daisies-Top.png" alt="Logo"></a>
<nav class="navbar">
    <a href="adminServices.php">Services</a>
    <a href="getcustomer.php">Customers</a>
    <a href="orders.php">Orders</a>
<a  href="../logout.php">Logout</a>

</nav>
</head>

<body>

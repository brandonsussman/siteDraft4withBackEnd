<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>Services</title>
	<link rel="stylesheet" href="styles.css" media="screen">
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../style.css">
	<link rel="stylesheet" href="../file.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<script src="script.js" defer></script>

	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<?php include "adminMenu.php" ?>

<body>

  <div class="flexbox-body">
    <div class="form-login">
<form method="post">
  <div class"title"><h2>Search Customers</h2></div>
<label>Enter customer's Name: </label><input type="text" placeholder="Name" class="input" name="name"><br/>
<label>Enter customer's Surname: </label><input type="text" class="input" placeholder="Surname" name="surname"><br/>
<label>Enter customer's Email: </label><input type="text" class="input" placeholder="Email" name="email"><br/>
<label>Enter customer's ID: </label><input type="text" class="input" placeholder="CustomerID" name="customerIDSearch"><br/>
<input type="submit" class="button" value="Search" name="search"> <br/>


</form>
</div>
</div>
<?php


if(!(isset($_POST['search'])))
{


  $sql = "SELECT * FROM customer";

  $query = mysqli_query($conn,$sql);?>

  <table>
  <tr>
    <th>CustomerID</th>
    <th>Name</th>
    <th>Surname</th>
    <th>Email</th>
    <th>Phone</th>
  </tr>
  <?php
  while ($result = mysqli_fetch_assoc($query)) { ?>


<tr>
  <td><?PHP echo $result['CustomerId']; ?></td>
  <td><?PHP echo $result['Name']; ?></td>
  <td><?PHP echo $result['Surname']; ?></td>
  <td><?PHP echo $result['EmailAdd']; ?></td>
  <td><?PHP echo $result['PhoneNumber']; ?></td>

</tr>







<?php
 }



} ?>
<?php


if((isset($_POST['search'])))
{


  $sql = "SELECT * FROM customer where Name like '%{$_POST['name']}%' and surname like '%{$_POST['surname']}%' and emailADD like '%{$_POST['email']}%'and CustomerId like '%{$_POST['customerIDSearch']}%' ";

  $query = mysqli_query($conn,$sql);?>

  <table>
  <tr>
    <th>CustomerID</th>
    <th>Name</th>
    <th>Surname</th>
    <th>Email</th>
    <th>Phone</th>
  </tr>
  <?php
  while ($result = mysqli_fetch_assoc($query)) { ?>


<tr>
  <td><?PHP echo $result['CustomerId']; ?></td>
  <td><?PHP echo $result['Name']; ?></td>
  <td><?PHP echo $result['Surname']; ?></td>
  <td><?PHP echo $result['EmailAdd']; ?></td>
  <td><?PHP echo $result['PhoneNumber']; ?></td>

</tr>







<?php
 }



} ?>

</table>











<div class="flexbox-body">
  <div class="form-login">
<form method= post>
    <div class"title"><h2>Delete Customer<h2></div>
  <label>Enter customer's ID: </label><input type="text" class="input" placeholder="Customer ID" name="customerID" ><br/>
  <input type="submit" class="button" value="Delete" name="Delete"> <br/>
</form>
</div>
</div>
</body>
<?php
if (isset($_POST['customerID'])) {
  // code...


$sqlDel = "Delete  FROM customer where customerID = '{$_POST['customerID']}' ";
$query2 = mysqli_query($conn,$sqlDel);
  mysqli_close($conn);
}
?>
</html>

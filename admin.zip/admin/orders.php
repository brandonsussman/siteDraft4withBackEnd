<?php session_start();?>
<?php include "../db_conn.php" ?>
<?php if(isset($_POST['complete'])){
 $sql= "UPDATE `orders` SET Delivery= 1 WHERE id =".$_POST['markDelivery'];

$result = mysqli_query($conn,$sql);
header("");


} if(isset($_POST['incomplete'])){
  $sql = "UPDATE `orders` SET Delivery= 0 WHERE id =".$_POST['markDelivery'];

$result = mysqli_query($conn,$sql);
header("");
}?>
<!DOCTYPE html>
<html>
<head>
	<title>Orders</title>
	<link rel="stylesheet" href="styles.css" media="screen">
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../style.css">
	<link rel="stylesheet" href="../file.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<script src="script.js" defer></script>

	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<?php include "adminMenu.php" ?>

<div class="flexbox-body">
  <div class="form-login">
<form method="post">
  <div class"title"><h2>Filter<h2></div>
  <div class"title"><h3>Delivery Status<h3></div>
 <select name="filDelivery" id="Filter">
  <option value=" ">Any</option>
<option value="and Delivery = 1">Complete</option>
<option value="and Delivery = 0">Incomplete</option>
</select>
</br>
<div class"title"><h3>Date<h3></div>
<select name="filDate" id="Filter">
<option value="Desc">Newest to Oldest</option>
<option value="Asc">Oldest to Newest</option>
</select>
</br>
  <div class"title"><h2>Search by Order Number, Username or Date<h2></div>
<label>Search: </label><input type="text" placeholder="search" class="input" name="searchTerm"><br/>
<input type="submit" value="search (and or filter)" class="button" name="search"> <br/>


</form>
</div>
</div>
<div id="ordSer">
  
  <form method="post">
  <div class"title"><h2>Mark Current delivery<h2></div>
<input type="hidden"  value="" id="markDelivery" name="markDelivery"> <br/>
<input type="submit" value="complete" class="button" name="complete"> <br/>
<input type="submit" value="incomplete" class="button" name="incomplete"> <br/>

</form>
  <h2 id="orderNumber">You currently have no order selected</h2>
 

</div>
<div>
  <br></br>
  
<?php if(! isset($_POST['search'])){?>
<h2>ORDERS</h2>
  
</div>
<table>
<tr>
  <th>Order Number</th>
  <th>USER</th>
  <th>COST (R)</th>
  <th>DATE</th>
  <th>STAND NUMBER</th>
  <th>ADDRESS</th>
  <th>DELIVERY</th>


<script> var serDisArr=[]; </script>
<?php

$sql = "SELECT * FROM customer_order left join orders on customer_order.ORDER_ID=orders.id left join customer on orders.customerEmail = customer.EmailAdd where orders.PaymentStatus='Complete'";
$query = mysqli_query($conn,$sql);
$temp = "";
while ($result = mysqli_fetch_assoc($query)) { 
if ($temp !=  $result['id']) {?>
		 	<p>
		 	  <tr>
 
<td>

<a href="javascript:displayService(<?PHP echo $result['id']; ?>,'<?PHP echo $result['Name']; ?>'+' ' +'<?PHP echo $result['Surname']; ?>','<?PHP echo $result['PhoneNumber']; ?>')">  <?PHP echo $result['id']; ?></a>
</td>

<td><?PHP echo $result['customerEmail']; ?></td>
<td><?PHP echo $result['COST']; ?></td>
<td><?PHP echo $result['Date']; ?></td>
<td><?PHP echo $result['STAND_NUM']; ?></td>
<td><?PHP echo $result['PICKUP_ADDRESS']; ?></td>
<td><?PHP if($result['Delivery']==='1'){echo "Complete";}else{echo "incomplete";}?></td>
</tr>

   	 </p>

		 <?php }
		  ?>


<script>


newSer={ordID: <?PHP echo $result["id"]; ?> , service:  <?php echo json_encode($result["SERVICE"]); ?>, cost:  <?php echo json_encode($result["PRICE"]); ?>, units:  <?php echo json_encode($result["NUM_SERVICE"]); ?>};
serDisArr.push(newSer);


</script>




<?php  $temp =  $result['id'];}


?>
</table>

<?php } ?>
<?php if(isset($_POST['search'])){?>
<h2>ORDERS</h2>
  
</div>
<table>
<tr>
  <th>Order Number</th>
  <th>USER</th>
  <th>COST (R)</th>
  <th>DATE</th>
  <th>STAND NUMBER</th>
  <th>ADDRESS</th>
  <th>DELIVERY</th>


<script> var serDisArr=[]; </script>
<?php

 $sql = "SELECT * FROM customer_order left join orders on customer_order.ORDER_ID=orders.id left join customer on orders.customerEmail = customer.EmailAdd
  where orders.PaymentStatus='Complete' and  (id like '%{$_POST['searchTerm']}%' or 
  customerEmail like '%{$_POST['searchTerm']}%' or Date like '%{$_POST['searchTerm']}%') ".$_POST['filDelivery']." Order by Date ".$_POST['filDate'];
  
$query = mysqli_query($conn,$sql);
$temp = "";
while ($result = mysqli_fetch_assoc($query)) { 
if ($temp !=  $result['id']) {?>
		 	<p>
		 	  <tr>
 
<td>

<a href="javascript:displayService(<?PHP echo $result['id']; ?>,'<?PHP echo $result['Name']; ?>'+' ' +'<?PHP echo $result['Surname']; ?>','<?PHP echo $result['PhoneNumber']; ?>')">  <?PHP echo $result['id']; ?></a>
</td>

<td><?PHP echo $result['customerEmail']; ?></td>
<td><?PHP echo $result['COST']; ?></td>
<td><?PHP echo $result['Date']; ?></td>
<td><?PHP echo $result['STAND_NUM']; ?></td>
<td><?PHP echo $result['PICKUP_ADDRESS']; ?></td>
<td><?PHP if($result['Delivery']==='1'){echo "Complete";}else{echo "incomplete";}?></td>
</tr>

   	 </p>

		 <?php }
		  ?>


<script>


newSer={ordID: <?PHP echo $result["id"]; ?> , service:  <?php echo json_encode($result["SERVICE"]); ?>, cost:  <?php echo json_encode($result["PRICE"]); ?>, units:  <?php echo json_encode($result["NUM_SERVICE"]); ?>};
serDisArr.push(newSer);


</script>




<?php  $temp =  $result['id'];}


?>
</table>

<?php } ?>
 
  </html>
  <script>
  function displayService(num,name,phone){
serDisArr.sort((a, b) => {
    return a.ordID - b.ordID;
});

searchIndex = serDisArr.findIndex((ser) => ser.ordID==num);
  n=searchIndex;
 if(document.getElementById("serTab")!=null)
 {
   document.getElementById("serTab").remove();
   
 }
 var mark= document.getElementById("markDelivery");
 mark.value=serDisArr[n].ordID;
    var serTab = document.createElement("table");
  serTab.name="serTab";
  serTab.id="serTab";

   serTab.style.border="1px solid black";
   serTab.style.cellspacing="0"
  document.getElementById("ordSer").appendChild(serTab);
document.getElementById("orderNumber").innerText= "You are looking at order " + serDisArr[n].ordID +" by " + name + " who can be contacted here " + phone;
 serHeading=document.createElement("th");
 serHeading.innerText="SERVICE";
   serHeading.style.width="150px";
   serHeading.style.border="1px solid black";
 serTab.appendChild(serHeading);
  serHeading=document.createElement("th");
 serHeading.innerText="UNITS (kg/units)";
   serHeading.style.width="150px";
   serHeading.style.border="1px solid black";
 serTab.appendChild(serHeading);
   serHeading=document.createElement("th");
 serHeading.innerText="COST (R)";
   serHeading.style.width="150px";
   serHeading.style.border="1px solid black";
 serTab.appendChild(serHeading);
 
while (serDisArr[n].ordID==num) {
 

  row= document.createElement("tr");
  row.name="serRow";
  row.id="serRow";
  row.style.padding="0px";
  serTab.appendChild(row);

  serField=document.createElement("td");
  serField.style.width="150px";
   serField.style.border="1px solid black";
  serField.innerText=serDisArr[n].service;
  row.appendChild(serField);
  serField=document.createElement("td");
  serField.style.width="150px";
   serField.style.border="1px solid black";
  serField.innerText=serDisArr[n].units;
  row.appendChild(serField);
   serField=document.createElement("td");
  serField.style.width="150px";
   serField.style.border="1px solid black";
  serField.innerText=serDisArr[n].cost;
  row.appendChild(serField);
  
  
n++;
}
}
  </script>








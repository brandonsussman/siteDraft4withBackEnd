<?php session_start();?>
<?php
include '../db_conn.php';
if(isset($_POST['edit']))
{
$sqlEdit = "Update services set Name = '{$_POST['edName']}',PricePerUnit = '{$_POST['edPricePerUnit']}', Unit = '{$_POST['edUnit']}' where SERVICE_ID = '{$_POST['hEdSerID']}'";
$query3 = mysqli_query($conn,$sqlEdit);
  mysqli_close($conn);
  header("");
}
?>
<?php
if(isset($_POST['Delete']))
{
$sqlDel = "Delete  FROM services where service_ID = '{$_POST['hEdSerID']}' ";
$query2 = mysqli_query($conn,$sqlDel);
  mysqli_close($conn);
  header("");
}
?>
<?php if(isset($_POST['insert']))
{
$sqlIn =  "INSERT INTO services (Name, PricePerUnit, Unit) VALUES('{$_POST['inName']}', '{$_POST['inPricePerUnit']}', '{$_POST['inUnit']}')";
$query4 = mysqli_query($conn,$sqlIn);
  mysqli_close($conn);
  header("");
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Services</title>
	<link rel="stylesheet" href="styles.css" media="screen">
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../style.css">
	<link rel="stylesheet" href="../file.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	<script src="script.js" defer></script>

	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<?php include "adminMenu.php" ?>
<body>
  <div class="flexbox-body">
    <div class="form-login">
        <div class"title"><h2>Filter</h2></div>
<form  method="post">
  <select name="Filter" id="Filter">
  <option value="">None</option>
<option value="Order By Name Asc">Name A-Z</option>
<option value="ORDER BY Name Desc">Name Z-A</option>
  <option value="ORDER BY PricePerUnit Desc">Price High to Low</option>
  <option value="ORDER BY PricePerUnit Asc">Price Low to High</option>
  
  
</select>
    <div class"title"><h2>Search Services</h2></div>
<label>Search: </label><input class="input" type="text" placeholder="search"  name="searchTerm"><br/>
<input type="submit" class="button" value="search (and or Filter)" name="search"> <br/>



</div>
</div>

</form>
<br></br>


<?php
if (isset($_POST['Filter'])){
  $order = $_POST['Filter'];
}
else{$order="";}


  
if(isset($_POST['search']))
{


  $sql = "SELECT * FROM services where Name like '%{$_POST['searchTerm']}%' or PricePerUnit like '%{$_POST['searchTerm']}%'  or Unit like '%{$_POST['searchTerm']}%' ".$order;

  $query = mysqli_query($conn,$sql);?>

  <table>
  <tr>
    <th>Service ID</th>
    <th>Name</th>
    <th>Price Per Unit</th>
    <th>Units</th>

  </tr>
  <?php
  
  while ($result = mysqli_fetch_assoc($query)) { ?>


<tr>
 <td><a href="javascript:displayService(<?PHP echo $result['SERVICE_ID']; ?>,'<?PHP echo $result['Name']; ?>','<?PHP echo $result['PricePerUnit']; ?>','<?PHP echo $result['Unit']; ?>')">  <?PHP echo $result['SERVICE_ID']; ?></a></td>
 
  
  <td><?PHP echo $result['Name']; ?></td>
  <td><?PHP echo $result['PricePerUnit']; ?></td>
    <td><?PHP echo $result['Unit']; ?></td>


</tr>







<?php  }


}?>
</table>

<?php




if(!isset($_POST['search']))
{
 

  $sql = "SELECT * FROM services ".$order;

  $query = mysqli_query($conn,$sql);?>

  <table>
  <tr>
    <th>Service ID</th>
    <th>Name</th>
    <th>Price Per Unit</th>
    <th>Units</th>

  </tr>
  <?php
  while ($result = mysqli_fetch_assoc($query)) { ?>


<tr>
 <td><a href="javascript:displayService(<?PHP echo $result['SERVICE_ID']; ?>,'<?PHP echo $result['Name']; ?>','<?PHP echo $result['PricePerUnit']; ?>','<?PHP echo $result['Unit']; ?>')">  <?PHP echo $result['SERVICE_ID']; ?></a></td>

  <td><?PHP echo $result['Name']; ?></td>
  <td><?PHP echo $result['PricePerUnit']; ?></td>
  <td><?PHP echo $result['Unit']; ?></td>


</tr>







<?php  }


}?>
</table>















<div class="flexbox-body">
  <div class="form-login">
<form method=post>
    <div class"title"><h2>Edit Service</h2></div>
  <label>ID </label><input class="input" placeholder="Service ID" type="hidden"  id="hEdSerID" name="hEdSerID">
  <label id="edSerID">None selected</label><br/>
  <label>Name: </label><input class="input" type="text" placeholder="Service Name" id="edName" name="edName"><br/>
  <label>Price Per Unit: </label><input class="input" type="text" placeholder="Price Per Unit" id="edPricePerUnit" name="edPricePerUnit"><br/>
  <label>Units: </label><input class="input" type="text" placeholder="Units" id="edUnit" name="edUnit"><br/>
  <input type="submit" class="button" value="Edit" name="edit"> 
  <input type="submit" class="button" value="Delete" name="Delete">
</form>
</div>
</div>

<div class="flexbox-body">
  <div class="form-login">
<form method=post>
    <div class"title"><h2>Insert Service</h2></div>
  <label>Enter new Service Name: </label><input class="input" type="text" placeholder="Service Name" name="inName"><br/>
  <label>Enter new Service Price Per Unit: </label><input class="input" type="text" placeholder="Price Per Unit" name="inPricePerUnit"><br/>
  <label>Enter new Service Units: </label><input class="input" type="text" placeholder="Units" name="inUnit"><br/>
  <input type="submit" class="button" value="Insert" name="insert"> <br/>
</form>
</div>
</div>

</body>
</html>
<script>

function displayService(id,edName,edPrice,edUnit){
  
      var lblID= document.getElementById("edSerID");
  lblID.innerHTML=id;
     var edID= document.getElementById("hEdSerID");
  edID.value=id;
document.getElementById("edName").value=edName;
document.getElementById("edPricePerUnit").value=edPrice;
document.getElementById("edUnit").value=edUnit;
   
 }
 
</script>
